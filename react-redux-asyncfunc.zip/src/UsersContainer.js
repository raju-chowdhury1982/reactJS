import React, { useEffect } from "react";
import { connect } from "react-redux";
import { fetchUsers } from "./redux";

function UsersContainer({ usersData, fetchUsers }) {
  useEffect(() => {
    fetchUsers();
    console.log(usersData.users);
  }, []);
  return usersData.loading ? (
    <h2>Loading...</h2>
  ) : usersData.error ? (
    <h2>{usersData.error}</h2>
  ) : (
    <div>
      <h2>Users List</h2>
      <table>
        <thead>
          <tr>
            <th>user-name</th>
            <th>user - username</th>
            <th>user - city</th>
            <th>user - companyName</th>
          </tr>
        </thead>
        {usersData &&
          usersData.users &&
          usersData.users.map((user) => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.username}</td>
              <td>{user.address.city}</td>
              <td>{user.company.name}</td>
            </tr>
          ))}
      </table>
    </div>
  );
}

const mapSateToProps = (state) => {
  return {
    usersData: state.users
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchUsers: () => dispatch(fetchUsers())
  };
};
export default connect(mapSateToProps, mapDispatchToProps)(UsersContainer);
