the async function call for react-redux
app will fetch the list of uses from an API end point 
and store data in a redux store
store?
state
action?
reducer?
state: an object with type
state = {
loading: true, //loading spiner for showing data fetching in progress
data: [], //emty array to hold list of users from server
error:"" //display an error if unable to fetch 
}

action:
FETCH_USERS_REQUEST //for fetching list of users
FETCH_USERS_SUCESS //for successfull data fetch
FETCH_USERS_FAILURE //for any error encounter

reducer: 
case: FETCH_USERS_REQUEST
  laoding:true
case: FETCH_USERS_SUCESS
  loading:false
  users: data(from API)
case: FETCH_USERS_FAILURE
  loading:false
  error:error(from API)

  package used 
  1.axios, 
  2.redux
  -devTool
  -logger
  -thunk (allows async action 
  creator return a function instead of action, 
  the function can now have side effect to perform 
  fetching data and dispatch regular action based on responses, 
  these function can then handle by redux reducer to 
  update redux state, then the component can have the 
  updated state to use display in jsx component file)
 3. react-redux
  apiUrl="https://jsonplaceholder.typicode.com/users"
